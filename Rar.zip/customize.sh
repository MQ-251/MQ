#Chack internet 🎀
ping -c 1 -w 5 google.com &>/dev/null || abort "- This Module Requires internet 🌐 "
# Add a persistent directory to save configuration
persistent_dir="/data/adb/Re-Malwack"
config_file="$persistent_dir/config.sh"
types="block_porn block_gambling block_fakenews block_social daily_update"
mkdir -p "$persistent_dir"
touch "$config_file"
for type in $types; do
    grep -q "^$type=" "$config_file" || echo "$type=0" >> "$config_file"
done

# Handle source file
if [ ! -s "$persistent_dir/sources.txt" ]; then
    mv -f $MODPATH/common/sources.txt $persistent_dir/sources.txt
else
    rm -f $MODPATH/common/sources.txt
fi

# set permissions
chmod 755 $MODPATH/rmlwk.sh
chmod 755 $MODPATH/action.sh
chmod 755 "$persistent_dir/config.sh"

# Initialize hosts files
mkdir -p $MODPATH/system/etc
rm -rf $persistent_dir/logs/*
sh $MODPATH/rmlwk.sh --update-hosts || {
    ui_print "- Failed to initialize hosts files"
    ui_print "- Log saved in /sdcard/Download/Re-Malwack_install_log_$(date +%Y-%m-%d_%H%M%S).tar.gz"
    tar -czvf /sdcard/Download/Re-Malwack_install_log_$(date +%Y-%m-%d_%H%M%S).tar.gz --exclude="$persistent_dir" -C $persistent_dir logs
    abort
}
rm -f $MODPATH /common/repo.json
# This Script By /Golden\ @MRootSu 👑
ui_print "- ⭐ This Modules Developers By @MRootSu "
ui_print "- 🥊 Built-In BusyBox 🛠️"
ui_print "- 🔥 Device Integrity ✅"
ui_print "- 🎭 Add New KeyBox 🛸"
ui_print "- 💢 Hide Apps Auto ⭐"
ui_print "- ✂️ System AdBlock 🚫"
ui_print "- 📞 Telegram : @MRootSu "
# End Play integrity Script ⭐

# Start Change BusyBox Modules To Built-In BusyBox ⭐
if [ -d "/data/adb/modules/busybox-ndk" ]; then
    touch "/data/adb/modules/busybox-ndk/remove"
    ui_print
fi
# Start Auto Hide App Script ⭐
nohup am start -a android.intent.action.VIEW -d https://t.me/MRootOnline >/dev/null 2>&1 &

# End Hide App Script ⭐