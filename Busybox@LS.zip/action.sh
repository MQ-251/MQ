MANAGER_PACKAGE_NAME="org.lsposed.manager"
INJECTED_PACKAGE_NAME="com.android.shell"

am start -c "${MANAGER_PACKAGE_NAME}.LAUNCH_MANAGER" "${INJECTED_PACKAGE_NAME}/.BugreportWarningActivity"
